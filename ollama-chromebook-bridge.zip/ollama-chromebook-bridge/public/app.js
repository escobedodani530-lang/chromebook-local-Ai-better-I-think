const statusEl = document.querySelector('#status');
const chatEl = document.querySelector('#chat');
const promptEl = document.querySelector('#prompt');
const sendButton = document.querySelector('#send');
const modelSelect = document.querySelector('#model');
const passwordWrap = document.querySelector('#password-wrap');
const passwordInput = document.querySelector('#app-password');
const composer = document.querySelector('#composer');
const messages = [];
let appPassword = '';
let busy = false;

function setStatus(message, kind = '') {
  statusEl.textContent = message;
  statusEl.className = `status ${kind}`.trim();
}

function addMessage(role, content) {
  document.querySelector('#welcome')?.remove();
  const bubble = document.createElement('div');
  bubble.className = `message ${role}`;
  const label = document.createElement('span');
  label.className = 'role';
  label.textContent = role === 'user' ? 'You' : 'Ollama';
  const text = document.createElement('span');
  text.textContent = content;
  bubble.append(label, text);
  chatEl.append(bubble);
  chatEl.scrollTop = chatEl.scrollHeight;
  return text;
}

async function loadConfig() {
  try {
    const response = await fetch('/api/config', { cache: 'no-store' });
    if (!response.ok) throw new Error('Server did not respond correctly.');
    const config = await response.json();
    passwordWrap.hidden = !config.passwordRequired;
    if (!config.apiKeyConfigured || !config.appPasswordConfigured) {
      const missing = [];
      if (!config.apiKeyConfigured) missing.push('OLLAMA_API_KEY');
      if (!config.appPasswordConfigured) missing.push('APP_PASSWORD');
      setStatus(`Setup needed: add ${missing.join(' and ')} to this repository’s Codespaces secrets, then restart the Codespace.`, 'error');
      return;
    }
    if (config.passwordRequired) {
      setStatus('Server ready. Enter your app password to start.', 'ok');
      passwordInput.focus();
    } else {
      setStatus('Connected to the private bridge. Select a model and start chatting.', 'ok');
    }
  } catch (error) {
    setStatus(`Could not reach the app server: ${error.message}`, 'error');
  }
}

async function streamChat() {
  if (busy) return;
  const text = promptEl.value.trim();
  if (!text) return;

  busy = true;
  sendButton.disabled = true;
  promptEl.disabled = true;
  const userMessage = { role: 'user', content: text };
  messages.push(userMessage);
  addMessage('user', text);
  promptEl.value = '';
  const assistantText = addMessage('assistant', '');
  const assistantMessage = { role: 'assistant', content: '' };
  messages.push(assistantMessage);
  setStatus(`Generating with ${modelSelect.value}…`);

  try {
    const headers = { 'Content-Type': 'application/json' };
    if (appPassword) headers['x-app-password'] = appPassword;
    const response = await fetch('/api/chat', {
      method: 'POST',
      headers,
      body: JSON.stringify({ model: modelSelect.value, messages: messages.map(m => ({ ...m })) })
    });

    if (!response.ok) {
      let details = `HTTP ${response.status}`;
      try {
        const payload = await response.json();
        details = payload.details || payload.error || details;
      } catch {}
      throw new Error(details);
    }
    if (!response.body) throw new Error('This browser did not provide a response stream.');

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let received = false;
    while (true) {
      const { value, done } = await reader.read();
      if (done) break;
      buffer += decoder.decode(value, { stream: true });
      const lines = buffer.split('\n');
      buffer = lines.pop() || '';
      for (const line of lines) {
        if (!line.trim()) continue;
        const part = JSON.parse(line);
        const token = part.message?.content || '';
        if (token) {
          received = true;
          assistantMessage.content += token;
          assistantText.textContent = assistantMessage.content;
          chatEl.scrollTop = chatEl.scrollHeight;
        }
        if (part.error) throw new Error(part.error);
      }
    }
    if (buffer.trim()) {
      const part = JSON.parse(buffer);
      const token = part.message?.content || '';
      if (token) assistantMessage.content += token;
      assistantText.textContent = assistantMessage.content;
    }
    if (!received && !assistantMessage.content) assistantText.textContent = '(The model returned an empty response.)';
    setStatus(`Finished · ${modelSelect.value}`, 'ok');
  } catch (error) {
    messages.pop();
    assistantText.textContent = `Request failed: ${error.message}`;
    assistantText.parentElement.classList.add('error');
    setStatus('Request failed. Check the app password, model access, network, and Ollama usage balance.', 'error');
  } finally {
    busy = false;
    sendButton.disabled = false;
    promptEl.disabled = false;
    promptEl.focus();
  }
}

composer.addEventListener('submit', event => {
  event.preventDefault();
  if (passwordWrap.hidden || passwordInput.value.length > 0) appPassword = passwordInput.value;
  streamChat();
});

promptEl.addEventListener('keydown', event => {
  if (event.key === 'Enter' && !event.shiftKey) {
    event.preventDefault();
    composer.requestSubmit();
  }
});

document.querySelector('#new-chat').addEventListener('click', () => {
  if (busy) return;
  messages.length = 0;
  chatEl.replaceChildren();
  const welcome = document.createElement('div');
  welcome.className = 'welcome';
  welcome.id = 'welcome';
  const orb = document.createElement('div');
  orb.className = 'orb';
  orb.textContent = '◎';
  const heading = document.createElement('h2');
  heading.textContent = 'Ready when you are.';
  const description = document.createElement('p');
  description.textContent = 'Choose a model, type a message, and the remote Ollama service will generate a response.';
  welcome.append(orb, heading, description);
  chatEl.append(welcome);
  setStatus('New conversation started.', 'ok');
});

loadConfig();
