# Ollama Cloud Chat for a Chromebook (via GitHub Codespaces)

This is a browser-based chat page that calls **Ollama Cloud** from a small Node.js server in GitHub Codespaces. Your Chromebook does not need Crostini, Linux, Docker, or the Ollama desktop app.

**Important distinction:** this uses Ollama's hosted cloud models. It does not run model weights on the Chromebook. The Chromebook is just the browser; the Codespace securely relays requests to Ollama Cloud.

## Before starting

- Use this only if GitHub Codespaces and its forwarded-port domain are allowed by your school's device/network rules. Do not try to evade a block. Ask school IT for approval if needed.
- You need a personal GitHub account with Codespaces access.
- You need an Ollama account and an API key: https://ollama.com/settings/keys
- Ollama Cloud usage is metered. A no-subscription account is not unlimited free inference; check https://ollama.com/pricing before using it.

## 1. Create a private GitHub repository

1. On GitHub, create a new repository. Set it to **Private**.
2. Add the files from this folder to the repository. Keep the `.devcontainer` folder and its `devcontainer.json` file.
3. Do not put an Ollama API key in any source file, commit, or browser field.

## 2. Add server-side secrets

In your repository, open **Settings → Secrets and variables → Codespaces → New repository secret**.

Add:

- `OLLAMA_API_KEY` — your key from https://ollama.com/settings/keys
- `APP_PASSWORD` — a long, unique password that you choose

The second secret is an extra password gate for the chat page. Store both values as GitHub Codespaces secrets. Never paste the API key into `app.js`, `index.html`, or the browser.

If you add/change secrets after a Codespace is already running, stop and restart the Codespace so its environment receives the updated secrets.

## 3. Create the remote Linux environment

1. In the repository, select **Code → Codespaces → Create codespace on main**.
2. Wait for the browser-based VS Code environment to load.
3. Open **Terminal → New Terminal**.
4. Run:

   ```bash
   npm start
   ```

The server listens on port 3000. The included Codespaces configuration forwards port 3000 and marks it **Private**.

## 4. Open the chat

1. Open the **Ports** panel in Codespaces.
2. Find port `3000` named **Ollama Chat**.
3. Open its forwarded URL. Keep the port **Private**; do not change it to Public.
4. Enter the `APP_PASSWORD` you saved as a Codespaces secret.
5. Start chatting.

The browser sends requests only to the same Codespaces app. The server adds the Ollama API key and calls `https://ollama.com/api/chat` server-side. The key is never returned to the page.

## Models included in the selector

- `gpt-oss:20b`
- `gemma4`
- `deepseek-v4.1-flash`
- `nemotron-3-super`

Model availability and prices can change. Your account may not have access to every model until it has the required usage balance or plan. Check Ollama's current model and pricing pages.

## Cost and usage control

Ollama Cloud is billed by token usage. Check the model's current input/output rates and your usage balance before sending long chats. This small app does not set a spending limit for your Ollama account. You can revoke its API key from Ollama settings at any time.

GitHub Codespaces also has compute/storage quotas. Stop the Codespace when you're finished. Personal accounts have included monthly usage, but it is limited; check your GitHub billing page.

## Troubleshooting

- **`missing OLLAMA_API_KEY`**: add the repository Codespaces secret, then stop and restart the Codespace.
- **`401` from this app**: re-enter the `APP_PASSWORD` secret value.
- **`401` from Ollama**: create a new Ollama API key and update the Codespaces secret.
- **`402` or payment/usage error**: the Ollama account may need usage credits or model access.
- **Model not found/access denied**: choose a model available to your Ollama account and update the allowlist in `server.js` if needed.
- **The forwarded link is blocked**: stop here and ask school IT whether GitHub Codespaces and `*.app.github.dev` are permitted. This project is not a method for bypassing a school filter.

## Security notes

- Keep the Codespaces forwarded port Private.
- Keep the repository Private.
- Keep `OLLAMA_API_KEY` only in Codespaces secrets; never commit it.
- Do not share the Codespaces URL, app password, or API key.
- The server limits request size, restricts model names, and does not log message contents or secrets.
