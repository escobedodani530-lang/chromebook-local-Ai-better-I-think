import http from 'node:http';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number.parseInt(process.env.PORT || '3000', 10);
const OLLAMA_API_KEY = process.env.OLLAMA_API_KEY;
const APP_PASSWORD = process.env.APP_PASSWORD || '';
const MAX_BODY_BYTES = 256 * 1024;
const ALLOWED_MODELS = new Set([
  'gpt-oss:20b',
  'gemma4',
  'deepseek-v4.1-flash',
  'nemotron-3-super'
]);

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8'
};

function sendJson(res, status, value) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Cache-Control': 'no-store',
    'X-Content-Type-Options': 'nosniff'
  });
  res.end(JSON.stringify(value));
}

function hasValidAppPassword(req) {
  const supplied = req.headers['x-app-password'];
  return Boolean(APP_PASSWORD) && typeof supplied === 'string' && supplied === APP_PASSWORD;
}

async function readJsonBody(req) {
  const chunks = [];
  let total = 0;
  for await (const chunk of req) {
    total += chunk.length;
    if (total > MAX_BODY_BYTES) {
      const error = new Error('Request body is too large.');
      error.statusCode = 413;
      throw error;
    }
    chunks.push(chunk);
  }
  try {
    return JSON.parse(Buffer.concat(chunks).toString('utf8'));
  } catch {
    const error = new Error('Request body must be valid JSON.');
    error.statusCode = 400;
    throw error;
  }
}

function validateMessages(messages) {
  if (!Array.isArray(messages) || messages.length < 1 || messages.length > 40) {
    return 'Send between 1 and 40 messages.';
  }
  for (const item of messages) {
    if (!item || !['system', 'user', 'assistant'].includes(item.role)) {
      return 'Each message must have a system, user, or assistant role.';
    }
    if (typeof item.content !== 'string' || item.content.length > 20000) {
      return 'Each message must contain text no longer than 20,000 characters.';
    }
  }
  return null;
}

async function serveStatic(res, pathname) {
  const files = new Map([
    ['/', 'index.html'],
    ['/index.html', 'index.html'],
    ['/styles.css', 'styles.css'],
    ['/app.js', 'app.js']
  ]);
  const filename = files.get(pathname);
  if (!filename) {
    sendJson(res, 404, { error: 'Not found.' });
    return;
  }
  try {
    const content = await readFile(path.join(__dirname, 'public', filename));
    res.writeHead(200, {
      'Content-Type': MIME_TYPES[path.extname(filename)],
      'Cache-Control': 'no-store',
      'X-Content-Type-Options': 'nosniff',
      'Content-Security-Policy': "default-src 'self'; connect-src 'self'; img-src 'self' data:; style-src 'self'; script-src 'self'; base-uri 'none'; frame-ancestors 'none'"
    });
    res.end(content);
  } catch {
    sendJson(res, 500, { error: 'The app files could not be read.' });
  }
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url || '/', `http://${req.headers.host || 'localhost'}`);

  if (req.method === 'GET' && url.pathname === '/api/config') {
    sendJson(res, 200, {
      apiKeyConfigured: Boolean(OLLAMA_API_KEY),
      appPasswordConfigured: Boolean(APP_PASSWORD),
      passwordRequired: true,
      models: [...ALLOWED_MODELS]
    });
    return;
  }

  if (req.method === 'POST' && url.pathname === '/api/chat') {
    if (!OLLAMA_API_KEY) {
      sendJson(res, 503, { error: 'The server is missing the OLLAMA_API_KEY Codespaces secret.' });
      return;
    }
    if (!APP_PASSWORD) {
      sendJson(res, 503, { error: 'The server is missing the APP_PASSWORD Codespaces secret.' });
      return;
    }
    if (!hasValidAppPassword(req)) {
      sendJson(res, 401, { error: 'The app password is incorrect.' });
      return;
    }

    let body;
    try {
      body = await readJsonBody(req);
    } catch (error) {
      sendJson(res, error.statusCode || 400, { error: error.message });
      return;
    }

    const model = typeof body.model === 'string' ? body.model : '';
    if (!ALLOWED_MODELS.has(model)) {
      sendJson(res, 400, { error: 'That model is not in this app’s allowlist.' });
      return;
    }
    const messageError = validateMessages(body.messages);
    if (messageError) {
      sendJson(res, 400, { error: messageError });
      return;
    }

    const controller = new AbortController();
    res.on('close', () => {
      if (!res.writableEnded) controller.abort();
    });
    const timeout = setTimeout(() => controller.abort(), 180000);

    try {
      const upstream = await fetch('https://ollama.com/api/chat', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${OLLAMA_API_KEY}`,
          'Content-Type': 'application/json',
          'Accept': 'application/x-ndjson'
        },
        body: JSON.stringify({ model, messages: body.messages, stream: true }),
        signal: controller.signal
      });

      if (!upstream.ok) {
        const details = await upstream.text();
        sendJson(res, upstream.status, {
          error: `Ollama returned HTTP ${upstream.status}.`,
          details: details.slice(0, 1500)
        });
        return;
      }

      res.writeHead(200, {
        'Content-Type': 'application/x-ndjson; charset=utf-8',
        'Cache-Control': 'no-store, no-transform',
        'X-Content-Type-Options': 'nosniff',
        'X-Accel-Buffering': 'no'
      });

      if (!upstream.body) {
        res.end();
        return;
      }
      for await (const chunk of upstream.body) {
        if (res.destroyed) break;
        if (!res.write(chunk)) {
          await new Promise(resolve => res.once('drain', resolve));
        }
      }
      if (!res.destroyed) res.end();
    } catch (error) {
      if (!res.headersSent) {
        sendJson(res, 502, {
          error: controller.signal.aborted
            ? 'The request timed out or was cancelled.'
            : 'Could not reach Ollama Cloud. Check the Codespace network connection.'
        });
      } else if (!res.destroyed) {
        res.end();
      }
    } finally {
      clearTimeout(timeout);
    }
    return;
  }

  if (req.method === 'GET') {
    await serveStatic(res, url.pathname);
    return;
  }
  sendJson(res, 405, { error: 'Method not allowed.' });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Ollama Cloud Bridge listening on port ${PORT}`);
  console.log('API keys are read from environment variables and are never sent to the browser.');
});
